
from Classes.AbstractOrder import AbstractOrder

class Order(AbstractOrder):
	
	def __init__(self, id):
		AbstractOrder.__init__(self, id)



